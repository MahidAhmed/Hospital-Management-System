<?php include "inc/header.php";?>
<?php include "lib/database.php";
    $db = new Database();
?>
    <div class="row about">
        <h2>FACILITIES</h2>
        <hr><br>

        <div>
            <ul>
                <li>Hospital information system (HIS).</li>
                <li>Computer networking system.</li>
                <li>One step quality diagnostic services to accumulate valuable time.</li>
                <li>Low service charge comparing with other standard labs.</li>
                <li>Well renounced and experienced consultants involves in reporting.</li>
                <li>Specialist doctors chamber.</li>
                <li>Emergency services without extra service charge.</li>
                <li>Availability of female technician.</li>
                <li>Report delivery by Courier and e-mail service also available.</li>
                <li>Own distillation plant.</li>
                <li>Comfortable waiting lounge.</li>
                <li>Neat and clean environment.</li>
                <li>Spacious parking facilities.</li>
                <li>Separate prayer room for male & female.</li>
                <li>Stand by generator set for constant power supply.</li>
            </ul>
        </div>
       
        </div>
<?php include "inc/footer.php";?>