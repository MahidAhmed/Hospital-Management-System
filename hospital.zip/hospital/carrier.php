<?php include "inc/header.php";?>

    <div class="row about">
        <hr><h2>CARRIER</h2>
        <hr>
        <p>Apollo Hospital has experienced consistent growth since its start, we are always searching for exceptional individuals to join our highly successful team.</p><br><br>
    </div>
<?php include "inc/footer.php";?>