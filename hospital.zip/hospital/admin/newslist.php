<?php 
include 'lib/database.php'; 
include 'config/config.php'; 

?>
<?php
    $db = new Database();
    $query = "SELECT * FROM news";
    $read = $db->select($query);
    
?>


<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>
        <div class="grid_10">
		
           <div class="box round first grid">
                <h2>News List</h2>
                <?php
                    if(isset($_GET['delId'])){
                        $delId = $_GET['delId'];
                        $dq= "delete from news where newsId='$delId'";
                        $del= $db->delete($dq);
                        if($del){
                            echo "<span>News deleted successfully</span>";
                        }else{
                            echo "<span>News not deleted</span>";
                        }
                    }
                ?>
                <div class="block">  
                    <table class="data display datatable" id="example">
					<thead>
						<tr>
							<th>Date</th>
                            <th>Title</th>
							<th>Action</th>
							
						
						</tr>
					</thead>
                        <?php if($read){
                              
                                while($row=$read->fetch_assoc()){
                                  
                                    ?>
                            <tbody>
                                <tr class="odd gradeX">
                                    <td><?php echo $row['date'];?></td>
                                    <td><?php echo $row['title'];?></td>
                                     <td><a href="editnews.php?id=<?php echo $row['newsId'];?>">Edit</a> || 
                                        <a onclick="return confirm('Are you sure to delete news');" href="?delId=<?php echo $row['newsId'];?>">Delete</a>
                                    </td>
                        <?php
                                
                        }  }else{?>
                        <p>Data is not available</p>
                        <?php
    
                        } ?>
				</table>
	
               </div>
            </div>
        </div>
<script type="text/javascript">
        $(document).ready(function () {
            setupLeftMenu();
		    setSidebarHeight();
        });
    </script>
 
       <?php include 'inc/footer.php'; ?>