<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>
<?php include 'lib/database.php'; ?>
<?php include 'helpers/format.php'; ?>
 <?php
      if(!isset($_GET['id']) || $_GET['id']==NULL){
                        //header("Location:doctorlist.php");
         }else{
                 $id = $_GET['id'];
             }
 ?>
        <div class="grid_10">
            <div class="box round first grid">
               <h2>Update Department</h2>
                <div class="block">  
                
                    <?php
                            $db = new Database();
                        if(isset($_POST['submit'])){
                            $name=mysqli_real_escape_string($db->link,$_POST['name']);
                           
                            
                            if($name == ''){
                                $error = "field must not be empty";
                            }else{
                                $query = "UPDATE department SET 
                                deptId=$id,
                                deptName='$name'
                                WHERE deptId = $id";
                                $create = $db->update($query);
                            }
                            
                        }
                    
                    
                    ?>
                    
                    
                    <?php
                        if(isset($error)){
                            echo $error;
                        }
                    
                    ?>
                   <?php
                    $query = "select * from department where deptId=$id";
                    $doc = $db->select($query);
                    while($result = $doc->fetch_assoc()){


                ?> 
                    
                 <form action="" method="post" enctype="multipart/form-data">
                    <table class="form">
                       
                        <tr>
                            <td>
                                <label>deptName</label>
                            </td>
                            <td>
                                <input type="text" name="name" value="<?php echo $result['deptName'];?>" class="medium" />
                            </td>
                        </tr>
                        
                        <tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Save" />
                            </td>
                        </tr>
					
                    </table>
                    </form>
                    
                    <?php }?>
                    
                </div>
            </div>
        </div>
    <?php include 'inc/footer.php'?>
<!-- Load TinyMCE -->
    <script src="js/tiny-mce/jquery.tinymce.js" type="text/javascript"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            setupTinyMCE();
            setDatePicker('date-picker');
            $('input[type="checkbox"]').fancybutton();
            $('input[type="radio"]').fancybutton();
        });
    </script>