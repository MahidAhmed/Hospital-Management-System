<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>
<?php include 'lib/database.php'; ?>
<?php include 'helpers/format.php'; ?>
        <div class="grid_10">
		
            <div class="box round first grid">
               <h2>Add Service</h2>
                <div class="block">  
                    
                    <?php
                       $db = new Database();
                        if(isset($_POST['submit'])){
                            $Stitle=mysqli_real_escape_string($db->link,$_POST['Stitle']);
                            $Sdescription=mysqli_real_escape_string($db->link,$_POST['Sdescription']);
                            
                            if($Stitle == '' || $Sdescription == ''){
                                $error = "field must not be empty";
                            }else{
                                 $query = "INSERT INTO service values('','$Stitle','$Sdescription')";
                                $create = $db->insert($query);
                            }
                            
                        }
                    
                    
                    ?>
                    
                    
                    <?php
                        if(isset($error)){
                            echo $error;
                        }
                    
                    ?>
                    
                    
                 <form action="addservice.php" method="post" enctype="multipart/form-data">
                    <table class="form">
                       
                    
						<tr>
                            <td>
                                <label>Title</label>
                            </td>
                            <td>
                                <input type="text" name="Stitle" placeholder="Enter Title" class="medium" />
                            </td>
                        </tr>
                       
                     
                        <tr>
                            <td>
                                <label>Description</label>
                            </td>
                            <td>
                                 <input type="text" rows="4" cols="50" name="Sdescription" placeholder="Enter Description" class="medium" />
                           
                               
                            </td>
                        </tr>
						<tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Save" />
                            </td>
                        </tr>
                    </table>
                    </form>
                    
                    
                    
                </div>
            </div>
        </div>
    <?php include 'inc/footer.php'?>
<!-- Load TinyMCE -->
    <script src="js/tiny-mce/jquery.tinymce.js" type="text/javascript"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            setupTinyMCE();
            setDatePicker('date-picker');
            $('input[type="checkbox"]').fancybutton();
            $('input[type="radio"]').fancybutton();
        });
    </script>