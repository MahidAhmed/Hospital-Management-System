<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>
<?php include 'lib/database.php'; ?>
<?php include 'helpers/format.php'; ?>
        <div class="grid_10">
		
            <div class="box round first grid">
               <h2>Add News</h2>
                <div class="block">  
                    
                    
                    <?php
                            $db = new Database();
                        if(isset($_POST['submit'])){
                            $date=mysqli_real_escape_string($db->link,$_POST['date']);
                            $title=mysqli_real_escape_string($db->link,$_POST['title']);
                            $descrip=mysqli_real_escape_string($db->link,$_POST['descrip']);
                           
                            
                            if($date == ''|| $title == ''|| $descrip == ''){
                                $error = "field must not be empty";
                            }else{
                                $qu = "INSERT INTO  news(date,title, description) values('$date','$title','$descrip')";
                                $create = $db->insert($qu);
                            }
                            
                        }
                    
                    
                    ?>
                    
                    
                    
                 <form action="addnews.php" method="post" enctype="multipart/form-data">
                    <table class="form">
                       
                        <tr>
                            <td>
                                <label>Date</label>
                            </td>
                            <td>
                                <input type="date" name="date" placeholder="Enter Current Date" class="medium" />
                            </td>
                        </tr>
                         <tr>
                            <td>
                                <label>Tiitle</label>
                            </td>
                            <td>
                                <input type="text" name="title" placeholder="Enter title of the news" class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Description</label>
                            </td>
                            <td>
                                <input type="text" name="descrip" placeholder="Enter description" class="medium" />
                            </td>
                        </tr>
                        
                        <tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Save" />
                            </td>
                        </tr>
					
                    </table>
                    </form>
                    
                    
                    
                </div>
            </div>
        </div>


    <?php include 'inc/footer.php'?>
<!-- Load TinyMCE -->
    <script src="js/tiny-mce/jquery.tinymce.js" type="text/javascript"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            setupTinyMCE();
            setDatePicker('date-picker');
            $('input[type="checkbox"]').fancybutton();
            $('input[type="radio"]').fancybutton();
        });
    </script>