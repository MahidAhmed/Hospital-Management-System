<?php 
include 'lib/database.php'; 
include 'config/config.php'; 

?>
<?php
    $db = new Database();
    $query = "SELECT * FROM department";
    $read = $db->select($query);
    
?>


<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>
        <div class="grid_10">
		
           <div class="box round first grid">
                <h2>Department List</h2>
                 <?php
                    if(isset($_GET['delId'])){
                        $delId = $_GET['delId'];
                        $dq= "delete from department where deptId='$delId'";
                        $del= $db->delete($dq);
                        if($del){
                            echo "<span>Department deleted successfully</span>";
                        }else{
                            echo "<span>Department not deleted</span>";
                        }
                    }
                ?>
                <div class="block">  
                    <table class="data display datatable" id="example">
					<thead>
						<tr>
							<th>Name</th>
                            <th>Action</th>
						</tr>
					</thead>
                        <?php if($read){
                                while($row=$read->fetch_assoc()){
                                    
                                    ?>
                            <tbody>
                                <tr class="odd gradeX">
                                    <td><?php echo $row['deptName'];?></td>
                                    <td><a href="updatedepartment.php?id=<?php echo $row['deptId'];?>">Edit</a> || <a onclick="return confirm('Are you sure to delete doctor');" href="?delId=<?php echo $row['deptId'];?>">Delete</a>
                                </tr>
                            </tbody>
                        <?php
                                
                        }  }else{?>
                        <p>Data is not available</p>
                        <?php
    
                        } ?>
				</table>
	
               </div>
            </div>
        </div>
    

    <script type="text/javascript">
        $(document).ready(function () {
            setupLeftMenu();
		    setSidebarHeight();
        });
    </script>
 
       <?php include 'inc/footer.php'; ?>