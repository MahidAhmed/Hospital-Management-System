<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>
<?php include 'lib/database.php'; ?>
<?php include 'helpers/format.php'; ?>
        <div class="grid_10">
		
            <div class="box round first grid">
               <h2>Add Instrument</h2>
                <div class="block">  
                    
                    
                    <?php
                            $db = new Database();
                        if(isset($_POST['submit'])){
                            $title=mysqli_real_escape_string($db->link,$_POST['title']);
                            $name=mysqli_real_escape_string($db->link,$_POST['name']);
                            $descrip=mysqli_real_escape_string($db->link,$_POST['descrip']);
                            $image=mysqli_real_escape_string($db->link,$_POST['image']);
                           
                            
                            if($title == ''|| $name == ''|| $descrip == '' || $image == ''){
                                $error = "field must not be empty";
                            }else{
                                $qu = "INSERT INTO  instrment values('','$title','$name','$descrip','$image')";
                                $create = $db->insert($qu);
                            }
                            
                        }
                    
                    
                    ?>
                    
                    
                    
                 <form action="addinstrument.php" method="post" enctype="multipart/form-data">
                    <table class="form">
                       
                        <tr>
                            <td>
                                <label>Title</label>
                            </td>
                            <td>
                                <input type="text" name="title" placeholder="Enter Title" class="medium" />
                            </td>
                        </tr>
                         <tr>
                            <td>
                                <label>Name</label>
                            </td>
                            <td>
                                <input type="text" name="name" placeholder="Enter name of the istrument" class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Description</label>
                            </td>
                            <td>
                                <input type="text" name="descrip" placeholder="Enter description" class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Image</label>
                            </td>
                            <td>
                                <input type="text" name="image" placeholder="Enter image name" class="medium" />
                            </td>
                        </tr>
                        
                        <tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Save" />
                            </td>
                        </tr>
					
                    </table>
                    </form>
                    
                    
                    
                </div>
            </div>
        </div>


    <?php include 'inc/footer.php'?>
<!-- Load TinyMCE -->
    <script src="js/tiny-mce/jquery.tinymce.js" type="text/javascript"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            setupTinyMCE();
            setDatePicker('date-picker');
            $('input[type="checkbox"]').fancybutton();
            $('input[type="radio"]').fancybutton();
        });
    </script>