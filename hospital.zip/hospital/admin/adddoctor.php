<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>
<?php include 'lib/database.php'; ?>
<?php include 'helpers/format.php'; ?>
        <div class="grid_10">
		
            <div class="box round first grid">
               <h2>Add New Doctor</h2>
                <div class="block">  
                    <?php
//                        $db = new Database();
//                        $que = "select deptId from department";
//                        $read = $db->select($que);
//                        if($read){
//                                while($row=$read->fetch_assoc()){
//                                    $i=$row['deptId'];
//                                }}
                    ?>
                    <?php
                      $db = new Database();
                        if(isset($_POST['submit'])){
                            $name=mysqli_real_escape_string($db->link,$_POST['name']);
                            $department=mysqli_real_escape_string($db->link,$_POST['dept']);
                            $speciality=mysqli_real_escape_string($db->link,$_POST['speciality']);
                            $degree=mysqli_real_escape_string($db->link,$_POST['degree']);
                            $organization=mysqli_real_escape_string($db->link,$_POST['organization']);
                            $workday=mysqli_real_escape_string($db->link,$_POST['workday']);
                            $visitingtime=mysqli_real_escape_string($db->link,$_POST['visitingtime']);
                            
                            if($name == '' || $department == '' || $speciality == '' || $degree == '' || $organization == '' || $workday == '' || $visitingtime == ''){
                                $error = "field must not be empty";
                            }else{
                                $query = "INSERT INTO doctor(name,deptId,speciality,degree,organization,workday,visiting_time) values('$name','$department','$speciality','$degree','$organization','$workday','$visitingtime')";
                                $create = $db->insert($query);
                            }
                            
                        }
                    
                    
                    ?>
                    
                    
                    <?php
                        if(isset($error)){
                            echo $error;
                        }
                    
                    ?>
                    
                    
                 <form action="adddoctor.php" method="post" enctype="multipart/form-data">
                    <table class="form">
                       
                    
						<tr>
                            <td>
                                <label>Name</label>
                            </td>
                            <td>
                                <input type="text" name="name" placeholder="Enter Doctor Name" class="medium" />
                            </td>
                        </tr>
                       
                     
                        <tr>
                            <td>
                                <label>Department</label>
                            </td>
                            <td>
                                 <select name="dept">
                                    <?php
                                    $db = new Database();
                                        $q = "SELECT * FROM department";
                                        $res = $db->select($q);
                                        if(mysqli_num_rows($res) > 0){
                                            while($rows = mysqli_fetch_array($res)){
                                                ?>

                                        <option value="<?php echo $rows['deptId']; ?>"><?php echo $rows['deptName']; ?></option>
                                        <?php

                                            }
                                        }
                                     ?>
                                </select>
                            </td>
                        </tr>
                       
                        <tr>
                            <td>
                                <label>Speciality</label>
                            </td>
                            <td>
                                <input type="text" name="speciality" placeholder="Speciality" class="medium" />
                            </td>
                        </tr>
						
						
						<tr>
                            <td>
                                <label>Degree</label>
                            </td>
                            <td>
                                <input type="text" name="degree" placeholder="Enter Degree" class="medium" />
                            </td>
                        </tr>
						
						<tr>
                            <td>
                                <label>Organization</label>
                            </td>
                            <td>
                                <input type="text" name="organization" placeholder="Enter Organization Name" class="medium" />
                            </td>
                        </tr>
						
						<tr>
                            <td>
                                <label>Work Day</label>
                            </td>
                            <td>
                                <input type="text" name="workday" placeholder="Enter Work Day" class="medium" />
                            </td>
                        </tr>
						
						<tr>
                            <td>
                                <label>Visiting Time</label>
                            </td>
                            <td>
                                <input type="time" name="visitingtime" placeholder="Enter Visiting Time" class="medium" />
                            </td>
                        </tr>
						
						<tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Save" />
                            </td>
                        </tr>
                    </table>
                    </form>
                    
                    
                    
                </div>
            </div>
        </div>
    <?php include 'inc/footer.php'?>
<!-- Load TinyMCE -->
    <script src="js/tiny-mce/jquery.tinymce.js" type="text/javascript"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            setupTinyMCE();
            setDatePicker('date-picker');
            $('input[type="checkbox"]').fancybutton();
            $('input[type="radio"]').fancybutton();
        });
    </script>