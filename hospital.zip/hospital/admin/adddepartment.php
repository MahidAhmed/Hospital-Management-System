<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>
<?php include 'lib/database.php'; ?>
<?php include 'helpers/format.php'; ?>
        <div class="grid_10">
		
            <div class="box round first grid">
               <h2>Add New Department</h2>
                <div class="block">  
                    
                    
                    <?php
                            $db = new Database();
                        if(isset($_POST['submit'])){
                            $name=mysqli_real_escape_string($db->link,$_POST['name']);
                           
                            
                            if($name == ''){
                                $error = "field must not be empty";
                            }else{
                                $query = "INSERT INTO department(deptName) values('$name')";
                                $create = $db->insert($query);
                            }
                            
                        }
                    
                    
                    ?>
                    
                    
                    <?php
                        if(isset($error)){
                            echo $error;
                        }
                    
                    ?>
                    
                    
                 <form action="adddepartment.php" method="post" enctype="multipart/form-data">
                    <table class="form">
                       
                        <tr>
                            <td>
                                <label>deptName</label>
                            </td>
                            <td>
                                <input type="text" name="name" placeholder="Enter Department Name" class="medium" />
                            </td>
                        </tr>
                        
                        <tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Save" />
                            </td>
                        </tr>
					
                    </table>
                    </form>
                    
                    
                    
                </div>
            </div>
        </div>
    <?php include 'inc/footer.php'?>
<!-- Load TinyMCE -->
    <script src="js/tiny-mce/jquery.tinymce.js" type="text/javascript"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            setupTinyMCE();
            setDatePicker('date-picker');
            $('input[type="checkbox"]').fancybutton();
            $('input[type="radio"]').fancybutton();
        });
    </script>