<?php 
include 'lib/database.php'; 
include 'config/config.php'; 

?>
<?php
    $db = new Database();
    $query = "SELECT * FROM patient";
    $read = $db->select($query);
    
?>


<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>
        <div class="grid_10">
		
           <div class="box round first grid">
                <h2>Doctor List</h2>
                <div class="block">  
                    <table class="data display datatable" id="example">
					<thead>
						<tr>
							<th>Name</th>
							<th>Gender</th>
							<th>Email</th>
							<th>Address</th>
                            <th>Age</th>
                            <th>Phone Number</th>
                            <th>Doctor</th>
                            <th>Appointment Date</th>
							
						
						</tr>
					</thead>
                        <?php if($read){
                              
                                while($row=$read->fetch_assoc()){
                                  
                                    ?>
                            <tbody>
                                <tr class="odd gradeX">
                                    <td><?php echo $row['patName'];?></td>
                                    <td><?php echo $row['gender'];?></td>
                                    <td><?php echo $row['email'];?></td>
                                    <td><?php echo $row['address'];?></td>
                                    <td><?php echo $row['age'];?></td>
                                    <td><?php echo $row['phNum'];?></td>
                                    <td><?php echo $row['doctor'];?></td>
                                    <td><?php echo $row['appDate'];?></td>
                            </tbody>
                        <?php
                                
                        }  }else{?>
                        <p>Data is not available</p>
                        <?php
    
                        } ?>
				</table>
	
               </div>
            </div>
        </div>
<script type="text/javascript">
        $(document).ready(function () {
            setupLeftMenu();
		    setSidebarHeight();
        });
    </script>
 
       <?php include 'inc/footer.php'; ?>