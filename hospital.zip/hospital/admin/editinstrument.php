<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>
<?php include 'lib/database.php'; ?>
<?php include 'helpers/format.php'; ?>
<?php
    if(!isset($_GET['id']) || $_GET['id']==NULL){
        //header("Location:doctorlist.php");
    }else{
        $id = $_GET['id'];
    }
?>
        <div class="grid_10">
		
            <div class="box round first grid">
               <h2>Update Instrument</h2>
                <div class="block">  
                    
                    
                    <?php
                            $db = new Database();
                        if(isset($_POST['submit'])){
                            $title=mysqli_real_escape_string($db->link,$_POST['title']);
                            $name=mysqli_real_escape_string($db->link,$_POST['name']);
                            $descrip=mysqli_real_escape_string($db->link,$_POST['descrip']);
                            $image=mysqli_real_escape_string($db->link,$_POST['image']);
                           
                            
                            if($title == ''|| $name == ''|| $descrip == '' || $image == ''){
                                $error = "field must not be empty";
                            }else{
                                $query = "UPDATE instrment SET
                                id= $id,
                                title= '$title',
                                name= '$name',
                                description= '$descrip',
                                image= '$image'

                                WHERE id = $id";
                                $create =  $db->update($query);
                            }
                            
                        }
                    
                    
                    ?>
                    
                   <?php
                    $query = "select * from instrment where id=$id";
                    $doc = $db->select($query);
                    while($result = $doc->fetch_assoc()){


                ?>  
                    
                 <form action="" method="post" enctype="multipart/form-data">
                    <table class="form">
                       
                        <tr>
                            <td>
                                <label>Title</label>
                            </td>
                            <td>
                                <input type="text" name="title" value="<?php echo $result['title']?>" class="medium" />
                            </td>
                        </tr>
                         <tr>
                            <td>
                                <label>Name</label>
                            </td>
                            <td>
                                <input type="text" name="name" value="<?php echo $result['name']?>" class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Description</label>
                            </td>
                            <td>
                                <input type="text" name="descrip" value="<?php echo $result['description']?>" class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Image</label>
                            </td>
                            <td>
                                <input type="text" name="image" value="<?php echo $result['image']?>" class="medium" />
                            </td>
                        </tr>
                        
                        <tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Save" />
                            </td>
                        </tr>
					
                    </table>
                    </form>
                    
                    <?php }?>
                    
                </div>
            </div>
        </div>


    <?php include 'inc/footer.php'?>
<!-- Load TinyMCE -->
    <script src="js/tiny-mce/jquery.tinymce.js" type="text/javascript"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            setupTinyMCE();
            setDatePicker('date-picker');
            $('input[type="checkbox"]').fancybutton();
            $('input[type="radio"]').fancybutton();
        });
    </script>