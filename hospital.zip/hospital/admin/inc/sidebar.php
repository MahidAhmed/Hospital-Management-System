<div class="grid_2">
            <div class="box sidemenu">
                <div class="block" id="section-menu">
                    <ul class="section menu">
                       <li><a class="menuitem">Department</a>
                            <ul class="submenu">
                                <li><a href="adddepartment.php">Add Department</a></li>
                                <li><a href="departmentlist.php">Department List</a></li>
                                
                            </ul>
                        </li>
						
                         <li><a class="menuitem">Doctor</a>
                            <ul class="submenu">
                                <li><a href="adddoctor.php">Add Doctor</a></li>
                                <li><a href="doctorlist.php">Doctor List</a></li>
                            </ul>
                        </li>
                        <li><a class="menuitem">News Option</a>
                            <ul class="submenu">
                                <li><a href="addnews.php">Add News</a> </li>
                                <li><a href="newslist.php">News List</a> </li>
                            </ul>
                        </li>
                        <li><a class="menuitem">Service Option</a>
                            <ul class="submenu">
                                <li><a href="addservice.php">Add Service</a> </li>
                                <li><a href="servicelist.php">Service List</a> </li>
                            </ul>
                        </li>
                        <li><a class="menuitem">Instrument</a>
                            <ul class="submenu">
                                <li><a href="addinstrument.php">Add Instrument</a> </li>
                                <li><a href="instrumentlist.php">Instrument List</a> </li>
                            </ul>
                        </li>
                        <li><a href="patientlist.php">Patient List</a></li>
                    </ul>
                </div>
            </div>
        </div>