<?php 
include 'lib/database.php'; 
include 'config/config.php'; 

?>
<?php
    $db = new Database();
    $query = "SELECT * FROM doctor";
    $read = $db->select($query);
    
?>


<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>
<div class="grid_10">
    <div class="box round first grid">
                <h2>Doctor List</h2>
                <?php
                    if(isset($_GET['delId'])){
                        $delId = $_GET['delId'];
                        $dq= "delete from doctor where id='$delId'";
                        $delDoc= $db->delete($dq);
                        if($delDoc){
                            echo "<span>Doctor deleted successfully</span>";
                        }else{
                            echo "<span>Doctor not deleted</span>";
                        }
                    }
                ?>
                <div class="block">  
                    <table class="data display datatable" id="example">
					<thead>
						<tr>
							<th>Name</th>
							<th>Degree</th>
							<th>Department</th>
							<th>Speciality</th>
							<th>Action</th>
						
						</tr>
					</thead>
                        <?php if($read){
                                $i=0;
                                while($row=$read->fetch_assoc()){
                                    $i=$row['deptId'];
                                    ?>
                            <tbody>
                                <tr class="odd gradeX">
                                    <td><?php echo $row['name'];?></td>
                                    <td><?php echo $row['degree'];?></td>
                                    <?php
                                        $q= "select deptName from department where deptId=$i";
                                        $re=$db->select($q);
                                        if($re){
                                            while($r=$re->fetch_assoc()){
                                                ?>
                                         <td><?php echo $r['deptName'];?></td>
                                      <?php }}  ?>
                                   
                                    <td><?php echo $row['speciality'];?></td>
                                   
                                    <td><a href="editdoctor.php?id=<?php echo $row['id'];?>">Edit</a> || 
                                        <a onclick="return confirm('Are you sure to delete doctor');" href="?delId=<?php echo $row['id'];?>">Delete</a>
                                    </td>
                                </tr>
                            </tbody>
                        <?php
                                
                        }  }else{?>
                        <p>Data is not available</p>
                        <?php
    
                        } ?>
				</table>
	
               </div>
            </div>
        </div>
<script type="text/javascript">
        $(document).ready(function () {
            setupLeftMenu();
		    setSidebarHeight();
        });
    </script>
 
       <?php include 'inc/footer.php'; ?>