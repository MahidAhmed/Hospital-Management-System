<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>
<?php include 'lib/database.php'; ?>
<?php include 'helpers/format.php'; ?>
<?php
    if(!isset($_GET['id']) || $_GET['id']==NULL){
        //header("Location:doctorlist.php");
    }else{
        $id = $_GET['id'];
    }
?>
        <div class="grid_10">
            <div class="box round first grid">
               <h2>Update Doctor</h2>
                <div class="block">  
                    <?php
                        $db = new Database();
                        $que = "select deptId from department where deptName=deptName";
                        $read = $db->select($que);
                        if($read){
                                while($row=$read->fetch_assoc()){
                                    $i=$row['deptId'];
                                }}
                    ?> 
                    <?php
//                        $db = new Database();
                        if(isset($_POST['submit'])){
                            $name=mysqli_real_escape_string($db->link,$_POST['name']);
                            $department=mysqli_real_escape_string($db->link,$_POST['department']);
                            //$department=$i;
                            $speciality=mysqli_real_escape_string($db->link,$_POST['speciality']);
                            $degree=mysqli_real_escape_string($db->link,$_POST['degree']);
                            $organization=mysqli_real_escape_string($db->link,$_POST['organization']);
                            $workday=mysqli_real_escape_string($db->link,$_POST['workday']);
                            $visitingtime=mysqli_real_escape_string($db->link,$_POST['visitingtime']);
                            
                            if($name == '' || $department == '' || $speciality == '' || $degree == '' || $organization == '' || $workday == '' || $visitingtime == ''){
                                $error = "field must not be empty";
                            }else{
                                $query = "UPDATE doctor SET
                                id=$id,
                                name= '$name', 
                                deptId=$department,
                                 speciality='$speciality',
                                 degree='$degree',
                                 organization='$organization',
                                 workday='$workday',
                                 visiting_time='$visitingtime'
                                WHERE id=$id";
                                $create = $db->update($query);
                                if($create){
                                    echo "Doctor Updated Successfully";
                                }else{
                                    echo "Doctor Not Updated";
                                }
                            }
                            
                        }
                    
                    
                    ?>
                    
                    
                    <?php
                        if(isset($error)){
                            echo $error;
                        }
                    
                    ?>
                <?php
                    $query = "select * from doctor where id=$id";
                    $doc = $db->select($query);
                    while($result = $doc->fetch_assoc()){


                ?>
                    
                 <form action="" method="post" enctype="multipart/form-data">
                    <table class="form">
                       
                    
						<tr>
                            <td>
                                <label>Name</label>
                            </td>
                            <td>
                                <input type="text" name="name" value="<?php echo $result['name']?>" class="medium" />
                            </td>
                        </tr>
                       
                     
                        <tr>
                            <td>
                                <label>Department</label>
                            </td>
                            <td>
                                 <select name="department">
                                    <?php
                                        $q = "SELECT * FROM department";
                                        $res = $db->select($q);
                                        if(mysqli_num_rows($res) > 0){
                                            while($rows = mysqli_fetch_array($res)){
                                                ?>

                                        <option value="<?php echo $rows['deptId']; ?>"><?php echo $rows['deptName']; ?></option>
                                        <?php

                                            }
                                        }
                                     ?>
                                </select>
                            </td>
                        </tr>
                       
                        <tr>
                            <td>
                                <label>Speciality</label>
                            </td>
                            <td>
                                <input type="text" name="speciality" value="<?php echo $result['speciality']?>" class="medium" />
                            </td>
                        </tr>
						
						
						<tr>
                            <td>
                                <label>Degree</label>
                            </td>
                            <td>
                                <input type="text" name="degree" value="<?php echo $result['degree']?>" class="medium" />
                            </td>
                        </tr>
						
						<tr>
                            <td>
                                <label>Organization</label>
                            </td>
                            <td>
                                <input type="text" name="organization" value="<?php echo $result['organization']?>" class="medium" />
                            </td>
                        </tr>
						
						<tr>
                            <td>
                                <label>Work Day</label>
                            </td>
                            <td>
                                <input type="text" name="workday" value="<?php echo $result['workday']?>" class="medium" />
                            </td>
                        </tr>
						
						<tr>
                            <td>
                                <label>Visiting Time</label>
                            </td>
                            <td>
                                <input type="time" name="visitingtime" value="<?php echo $result['visiting_time']?>" class="medium" />
                            </td>
                        </tr>
						
						<tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Save" />
                            </td>
                        </tr>
                    </table>
                    </form>
                    
                    <?php }?>
                    
                </div>
            </div>
        </div>
    <?php include 'inc/footer.php'?>
<!-- Load TinyMCE -->
    <script src="js/tiny-mce/jquery.tinymce.js" type="text/javascript"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            setupTinyMCE();
            setDatePicker('date-picker');
            $('input[type="checkbox"]').fancybutton();
            $('input[type="radio"]').fancybutton();
        });
    </script>