<?php include 'lib/session.php';
        Session::init();
?>
<?php include 'config/config.php';?>
<?php include 'lib/database.php';?>
<?php include 'helpers/format.php';?>
<?php
    $db=new Database();
    $fm=new Format();
?>



<!DOCTYPE html>
<head>
<meta charset="utf-8">
<title>Login</title>
    <link rel="stylesheet" type="text/css" href="css/stylelogin.css" media="screen" />
</head>
<body>
<div class="container">
	<section id="content">
        <?php 
            if($_SERVER['REQUEST_METHOD']=='POST'){
                $username=$fm->validation($_POST['username']);
                $password=$fm->validation(md5($_POST['password']));
                
                
               $username=mysqli_real_escape_string($db->link, $username);
               $password=mysqli_real_escape_string($db->link, $password);
                
                $query = "select * from admin where adminName='$username' AND password='$password'";
                
                $result=$db->select($query);
                
                if($result !=false){
                    $value= mysqli_fetch_array($result);
                    $row = mysqli_num_rows($result);
                    
                    if($row>0){
                        Session::set("login",true);
                        Session::set("username",$value['username']);
                        Session::set("userId",$value['id']);
                        header("Location: index.php");
                    }else{
                        echo "<span style='color:red; fontsize:18px'>No result found .</span>";
                    }
                }else{
                    echo "<span style='color:red; fontsize:18px'>Username or password not matched !! .</span>";
                }
            }
        ?>
		<form action="login.php" method="post">
	
			<h1>Apollo Hospital Ltd</h1>
			<h2>Admin Login</h2>
			<div>
				<input type="text" placeholder="Username" required="1" name="username"/>
			</div>
			<div>
				<input type="password" placeholder="Password" required="1" name="password"/>
			</div>
			<div>
				<input type="submit" name="submit" value="Log in" />
			</div>
		</form><!-- form -->
		
	</section><!-- content -->
</div><!-- container -->
</body>
</html>