<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>
<?php include 'lib/database.php'; ?>
<?php include 'helpers/format.php'; ?>
<?php
    if(!isset($_GET['id']) || $_GET['id']==NULL){
        //header("Location:doctorlist.php");
    }else{
        $id = $_GET['id'];
    }
?>
        <div class="grid_10">
		
            <div class="box round first grid">
               <h2>Add News</h2>
                <div class="block">  
                    
                    
                    <?php
                            $db = new Database();
                        if(isset($_POST['submit'])){
                            $date=mysqli_real_escape_string($db->link,$_POST['date']);
                            $title=mysqli_real_escape_string($db->link,$_POST['title']);
                            $descrip=mysqli_real_escape_string($db->link,$_POST['descrip']);
                           
                            
                            if($date == ''|| $title == ''|| $descrip == ''){
                                $error = "field must not be empty";
                            }else{
                                $query = "UPDATE news SET
                                newsId= $id,
                                date = '$date',
                                title ='$title',
                                description= '$descrip'

                                WHERE newsId = $id";
                                $create =  $db->update($query);
                            }
                            
                        }
                    
                    
                    ?>
                    
                   <?php
                    $query = "select * from news where newsId=$id";
                    $doc = $db->select($query);
                    while($result = $doc->fetch_assoc()){


                ?> 
                    
                 <form action="" method="post" enctype="multipart/form-data">
                    <table class="form">
                       
                        <tr>
                            <td>
                                <label>Date</label>
                            </td>
                            <td>
                                <input type="date" name="date" value="<?php echo $result['date']?>" class="medium" />
                            </td>
                        </tr>
                         <tr>
                            <td>
                                <label>Title</label>
                            </td>
                            <td>
                                <input type="text" name="title" value="<?php echo $result['title']?>" class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Description</label>
                            </td>
                            <td>
                                <input type="text" name="descrip" value="<?php echo $result['description']?>" class="medium" />
                            </td>
                        </tr>
                        
                        <tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Save" />
                            </td>
                        </tr>
					
                    </table>
                    </form>
                    
                    <?php }?>
                    
                </div>
            </div>
        </div>


    <?php include 'inc/footer.php'?>
<!-- Load TinyMCE -->
    <script src="js/tiny-mce/jquery.tinymce.js" type="text/javascript"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            setupTinyMCE();
            setDatePicker('date-picker');
            $('input[type="checkbox"]').fancybutton();
            $('input[type="radio"]').fancybutton();
        });
    </script>