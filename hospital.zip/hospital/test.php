<?php include "inc/header.php";?>
<?php include "lib/database.php";
    $db = new Database();
?>
    <div class="row about">
        <h2>TEST PROCEDURE</h2>
        <hr><br>
        <h3>Requirements for 24 hour Urinary Test</h3>
        <div>
            <ul>
                <li>Collect your urine in a 3/4 litters well clean color plastic pot. Don’t use white or Oily pot.</li>
                <li>Don’t put first urine of morning, in the pot.</li>
                <li>Wake up in the morning and release Urine in the Toilet. Start collecting your urine from 2nd time, and keep collecting for the next 24hours. (For example: if you started collecting Urine from 8:00am then you must keep collecting your urine next morning till 8:00am.)</li>
                <li>If somehow you failed to collect your full urine the test will fail..</li>
                <li>After putting your urine 1 to 2 times in the pot put the liquid provided by us in the pot.</li>
                <li>After collecting all your urine bring the urine pot to us.</li>

            </ul>
        </div>
       
        </div>
<?php include "inc/footer.php";?>