<?php include "inc/header.php";?>
<?php include "lib/database.php";
    $db = new Database();
?>
    <div class="row about">
        <h2>ACHIEVEMENT</h2><hr>
        <hr><br>

        <div>
            
            <h3>Honoured by Apelem</h3><br>
            <p>In May 2015 Apollo Hospital Limited has introduced a new True Digital Radiography & Fluoroscopy X-Ray has been introduced called Platinum. A french Company called Apelem DMS is the manufacturer of Platinum X-ray. Thiis the 1st unit in Asia that has been installed in the premises  of  Apollo Hospital Limited</p><br>


        </div>
       
        </div>
<?php include "inc/footer.php";?>