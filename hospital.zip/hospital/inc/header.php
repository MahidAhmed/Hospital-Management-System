<!DOCTYPE html>
<html>
<head>
	<title>Basic Website</title>
	
	<link rel="stylesheet" href="css/font-awesome.min.css">	
	<link rel="stylesheet" href="css/nivo-slider.css" type="text/css" media="screen" />
	<link rel="stylesheet" href="style.css">
	<script src="js/jquery.js" type="text/javascript"></script>
	<script src="js/jquery.nivo.slider.js" type="text/javascript"></script>
	<link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

<script type="text/javascript">
$(window).load(function() {
	$('#slider').nivoSlider({
		effect:'random',
		slices:10,
		animSpeed:500,
		pauseTime:5000,
		startSlide:0, //Set starting Slide (0 index)
		directionNav:false,
		directionNavHide:false, //Only show on hover
		controlNav:false, //1,2,3...
		controlNavThumbs:false, //Use thumbnails for Control Nav
		pauseOnHover:true, //Stop animation while hovering
		manualAdvance:false, //Force manual transitions
		captionOpacity:0.8, //Universal caption opacity
		beforeChange: function(){},
		afterChange: function(){},
		slideshowEnd: function(){} //Triggers after all slides have been shown
	});
});
</script>
</head>

<body class="container">
	<div class="header_container row">
		<div class="header_left">
            <a href="#" title="">
                <img src="image/hos_Img.png" alt="logo" />
            </a>
        </div>
		
       <div class="nav">
           
               <div id="" class="menu_btn">
					<div class="dropdown">
						<a href="index.php"><button class="dropbtn">HOME</button></a>
				    </div>
			   </div>
			   
	
               <div id="" class="menu_btn">
			   
				   <div class="dropdown">
					  <button class="dropbtn">SERVICES</button>
					  <div class="dropdown-content">
						<a href="service.php?id=2">Cardiac Imaging Services</a>
						<a href="service.php?id=1">Gastroenterology Service</a>
						<a href="service.php?id=3">Clinical Laboratory Services</a>
						<a href="service.php?id=4">Pulmonology Service</a>
						<a href="service.php?id=5">Radiology and Imaging</a>
						<a href="service.php?id=6">Urology Services</a>
						<a href="service.php?id=7">Clinical Neuro Physiology</a>
					  </div>
					</div>
                    
               </div>
               <div id="" class="menu_btn">
					
					<div class="dropdown">
					   <button class="dropbtn">CONSULTANT</button>
					    <div class="dropdown-content">
						
							<a href="consultant.php">consultant list</a>
						</div>
					</div>
                </div>
                <div id="" class="menu_btn">
					<div class="dropdown">
					  <a href="appoint.php"><button class="dropbtn">APPOINTMENT</button></a>
					</div>
              </div>
               <div id="" class="menu_btn">
					
					<div class="dropdown">
					  <button class="dropbtn">INSTRUMENT</button>
					  <div class="dropdown-content">
					  	<a href="instrument.php?id=1">Pulmonology Instrument</a>
						<a href="instrument.php?id=2">Laboratory Instruments</a>
						<a href="instrument.php?id=3">Cardiac Imaging Instrument</a>
						<a href="instrument.php?id=4">Gastroenterology Instruments</a>
						<a href="instrument.php?id=5">Radiology and Imaging Instrument</a>
						<a href="instrument.php?id=6">Physiotherapy Instruments</a>
						<a href="instrument.php?id=7">Urology Instruments</a>
						<a href="instrument.php?id=8">Clinical Neuro Physiology Instrument</a>
					  </div>
					</div>
					
                   
               </div>
               <div id="" class="menu_btn">
					
					<div class="dropdown">
					  <button class="dropbtn">INFORMATION</button>
					  <div class="dropdown-content">
						<a href="facilities.php">Facilities</a>
						<a href="quality.php">Quality Control</a>
						<a href="achievement.php">Achievement</a>
						<a href="test.php">Test Procedures</a>
					  </div>
					</div>
               </div>
               <div id="" class="menu_btn">
					<div class="dropdown">
					  <button class="dropbtn">COMPANY</button>
					  <div class="dropdown-content">
						<a href="about.php">About Us</a>
						<a href="news.php">News</a>
						<a href="carrier.php">Career</a>
					  </div>
					</div>
               </div>
               
               
        
		</div>
	</div>